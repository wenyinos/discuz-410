<?php
//Discuz! cache file, DO NOT modify me!
//Created on Nov 23, 2025, 5:30

$_DCACHE['announcements_forum'] = Array
	(
	'id' => 1,
	'author' => 'ruojiner',
	'message' => '本论坛地址� ...',
	'authorid' => 1,
	'subject' => '本论坛地址已更新为 bbs.wenyinos.com  原地址已做重定向处理。',
	'starttime' => 612892800
	);

$_DCACHE['globalstick'] = Array
	(
	'global' => Array
		(
		'tids' => '0',
		'count' => '0'
		)
	);

$_DCACHE['forums'] = Array
	(
	1 => Array
		(
		'fid' => 1,
		'type' => 'forum',
		'name' => '经典Windows',
		'fup' => 2,
		'viewperm' => ''
		),
	2 => Array
		(
		'fid' => 2,
		'type' => 'group',
		'name' => '综合讨论',
		'fup' => '0',
		'viewperm' => ''
		),
	5 => Array
		(
		'fid' => 5,
		'type' => 'forum',
		'name' => '经典的其他系统',
		'fup' => 2,
		'viewperm' => ''
		),
	6 => Array
		(
		'fid' => 6,
		'type' => 'forum',
		'name' => '经典硬件交流&选购',
		'fup' => 2,
		'viewperm' => ''
		),
	7 => Array
		(
		'fid' => 7,
		'type' => 'forum',
		'name' => '常用经典软件（附件尺寸16MB）',
		'fup' => 3,
		'viewperm' => ''
		),
	8 => Array
		(
		'fid' => 8,
		'type' => 'forum',
		'name' => '闲聊畅谈',
		'fup' => 4,
		'viewperm' => ''
		),
	3 => Array
		(
		'fid' => 3,
		'type' => 'group',
		'name' => '软件资源',
		'fup' => '0',
		'viewperm' => ''
		),
	4 => Array
		(
		'fid' => 4,
		'type' => 'group',
		'name' => '闲聊畅谈',
		'fup' => '0',
		'viewperm' => ''
		)
	);

$_DCACHE['icons'] = Array
	(
	19 => 'icon1.gif',
	20 => 'icon2.gif',
	21 => 'icon3.gif',
	22 => 'icon4.gif',
	23 => 'icon5.gif',
	24 => 'icon6.gif',
	25 => 'icon7.gif',
	26 => 'icon8.gif',
	27 => 'icon9.gif'
	);

$_DCACHE['onlinelist'] = Array
	(
	'legend' => '<img src="images/common/online_admin.gif"> 管理员 &nbsp; &nbsp; &nbsp; <img src="images/common/online_supermod.gif"> 超级版主 &nbsp; &nbsp; &nbsp; <img src="images/common/online_moderator.gif"> 版主 &nbsp; &nbsp; &nbsp; <img src="images/common/online_member.gif"> 会员 &nbsp; &nbsp; &nbsp; ',
	1 => 'online_admin.gif',
	2 => 'online_supermod.gif',
	3 => 'online_moderator.gif',
	0 => 'online_member.gif'
	);

?>