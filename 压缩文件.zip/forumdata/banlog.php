<?PHP exit('Access Denied'); ?>
